package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.KonyvController;
import adatb.konyvesbolt.controller.KonyvesboltController;
import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.model.Konyvesbolt;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;
import static adatb.konyvesbolt.dao.DatabaseStrings.PASSWORD;

public class KonyvesboltAdminController implements Initializable {

    @FXML
    private TableView<Konyvesbolt> MainPageTable;
    @FXML
    private TableColumn<Konyvesbolt, String> nameCol;

    @FXML
    private TextField searchField;

    public static Konyvesbolt oldKonyvesbolt;

    public KonyvesboltAdminController() {
    }

    @FXML
    public void addBookStoreAdmin() {

        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/KonyvesboltAdd.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void updateBookStoreAdmin() {
        Parent root = null;
        oldKonyvesbolt = MainPageTable.getSelectionModel().getSelectedItem();
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/KonyvesboltUpdate.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void deleteBookStoreAdmin() {
        Konyvesbolt kb = MainPageTable.getSelectionModel().getSelectedItem();
        int selectedIndex = MainPageTable.getSelectionModel().getSelectedIndex();

        if (selectedIndex >= 0) {
            Optional<ButtonType> result = AlertsForUser.confirmationAlert("Biztos, hogy törlöd a kiválasztott könyvesboltot?");
            if(result.get() == ButtonType.OK) {
                try(Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement st = conn.prepareStatement("DELETE" +
                        " FROM KONYVESBOLT WHERE BOLT_NEV LIKE ? ")) {

                    st.setString(1, kb.getBolt_nev());

                    int res = st.executeUpdate();
                    if (res == 1) {
                        MainPageTable.getItems().remove(selectedIndex);
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @FXML
    public void searchBookStore() {
        String text = "'%" + searchField.getText() + "%'";
        List<Konyvesbolt> result = new ArrayList<>();
        if(searchField.getText().isEmpty()) {
            List<Konyvesbolt> bookList = KonyvesboltController.getInstance().getAll();
            MainPageTable.setItems(FXCollections.observableList(bookList));
        } else {
            try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
                ResultSet rs = st.executeQuery("SELECT * FROM KONYVESBOLT WHERE BOLT_NEV LIKE " + text);

                while (rs.next()) {
                    Konyvesbolt kb = new Konyvesbolt(
                            rs.getString(1)
                    );
                    result.add(kb);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            List<Konyvesbolt> bookList = result;
            MainPageTable.setItems(FXCollections.observableList(bookList));
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        nameCol.setCellValueFactory(new PropertyValueFactory<>("bolt_nev"));

        List<Konyvesbolt> bookList = KonyvesboltController.getInstance().getAll();
        MainPageTable.setItems(FXCollections.observableList(bookList));
    }
}
