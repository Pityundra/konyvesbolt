package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.KonyvController;
import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.Calendar;
import java.util.ResourceBundle;

public class KonyvAddController implements Initializable {

    @FXML
    private TextField idField;
    @FXML
    private TextField cimField;
    @FXML
    private TextField mufajField;
    @FXML
    private TextField kiadasi_evField;
    @FXML
    private TextField arField;
    @FXML
    private TextField darabField;
    @FXML
    private Button okButton;

    public KonyvAddController() {
    }

    @FXML
    public void save(ActionEvent event) {

        Konyv konyv = new Konyv();
        konyv.setId(Integer.parseInt(idField.getText()));
        konyv.setCim(cimField.getText());
        konyv.setMufaj(mufajField.getText());
        konyv.setKiadasi_ev(kiadasi_evField.getText());
        konyv.setAr(Integer.parseInt(arField.getText()));
        konyv.setDarab(Integer.parseInt(darabField.getText()));

        if (KonyvController.getInstance().add(konyv)) {
            AlertsForUser.successAlert("Sikerült a könyv hozzáadása!");
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        } else {
            AlertsForUser.errorAlert("Hiba történt a könyv hozzáaadása során!");
            return;
        }
    }

    @FXML
    public void cancel(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
