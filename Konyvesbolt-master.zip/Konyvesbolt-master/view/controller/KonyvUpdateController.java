package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.KonyvController;
import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class KonyvUpdateController implements Initializable {
    @FXML
    private TextField idField;
    @FXML
    private TextField cimField;
    @FXML
    private TextField mufajField;
    @FXML
    private TextField kiadasi_evField;
    @FXML
    private TextField arField;
    @FXML
    private TextField darabField;
    @FXML
    private Button okButton;

    public KonyvUpdateController() {
    }

    @FXML
    public void update(ActionEvent event) {

        Konyv konyvOld = MainPageAdminController.oldKonyv;

        Konyv konyvNew = new Konyv();
        konyvNew.setId(Integer.parseInt(idField.getText()));
        konyvNew.setCim(cimField.getText());
        konyvNew.setMufaj(mufajField.getText());
        konyvNew.setKiadasi_ev(kiadasi_evField.getText());
        konyvNew.setAr(Integer.parseInt(arField.getText()));
        konyvNew.setDarab(Integer.parseInt(darabField.getText()));

        if(KonyvController.getInstance().update(konyvNew, konyvOld)) {
            AlertsForUser.successAlert("Sikerült a könyv frissítése!");
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        } else {
            AlertsForUser.errorAlert("Hiba történt a könyv frissítése során!");
            return;
        }
    }

    @FXML
    public void cancel(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
