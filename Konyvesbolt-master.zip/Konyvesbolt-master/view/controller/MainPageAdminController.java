package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.App;
import adatb.konyvesbolt.controller.CollectiveMethods;
import adatb.konyvesbolt.controller.KonyvController;
import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;

public class MainPageAdminController implements Initializable {

    @FXML
    private TableView<Konyv> MainPageTable;
    @FXML
    private TableColumn<Konyv, Integer> idCol;
    @FXML
    private TableColumn<Konyv, String> cimCol;
    @FXML
    private TableColumn<Konyv, String> mufajCol;
    @FXML
    private TableColumn<Konyv, String> kiadasiEvCol;
    @FXML
    private TableColumn<Konyv, Integer> arCol;
    @FXML
    private TableColumn<Konyv, Integer> darabCol;

    @FXML
    private TextField searchField;

    public static Konyv oldKonyv;

    public MainPageAdminController() {
    }

    @FXML
    public void addBookAdmin() {

        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/KonyvAdd.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void updateBookAdmin() {
        Parent root = null;
        oldKonyv = MainPageTable.getSelectionModel().getSelectedItem();
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/KonyvUpdate.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void deleteBookAdmin() {
        Konyv k = MainPageTable.getSelectionModel().getSelectedItem();
        int selectedIndex = MainPageTable.getSelectionModel().getSelectedIndex();

        if (selectedIndex >= 0) {
            Optional<ButtonType> result = AlertsForUser.confirmationAlert("Biztos, hogy törlöd a kiválasztott könyvet?");
            if(result.get() == ButtonType.OK) {
                try(Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement st = conn.prepareStatement("DELETE" +
                        " FROM KONYV WHERE CIM LIKE ? ")) {

                    st.setString(1, k.getCim());

                    int res = st.executeUpdate();
                    if (res == 1) {
                        MainPageTable.getItems().remove(selectedIndex);
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @FXML
    public void tableBookStore() {
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/Konyvesbolt.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void searchBook() {
        String text = "'%" + searchField.getText() + "%'";
        List<Konyv> result = new ArrayList<>();
        if(searchField.getText().isEmpty()) {
            List<Konyv> bookList = KonyvController.getInstance().getAll();
            MainPageTable.setItems(FXCollections.observableList(bookList));
        } else {
            try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
                ResultSet rs = st.executeQuery("SELECT * FROM KONYV WHERE CIM LIKE " + text);

                while (rs.next()) {
                    Konyv k = new Konyv(
                            rs.getInt(1),
                            rs.getString(2),
                            rs.getString(3),
                            rs.getString(4),
                            rs.getInt(5),
                            rs.getInt(6)
                    );
                    result.add(k);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            List<Konyv> bookList = result;
            MainPageTable.setItems(FXCollections.observableList(bookList));
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        idCol.setCellValueFactory(new PropertyValueFactory<>("konyv_id"));
        cimCol.setCellValueFactory(new PropertyValueFactory<>("cim"));
        mufajCol.setCellValueFactory(new PropertyValueFactory<>("mufaj"));
        kiadasiEvCol.setCellValueFactory(new PropertyValueFactory<>("kiadasi_ev"));
        arCol.setCellValueFactory(new PropertyValueFactory<>("ar"));
        darabCol.setCellValueFactory(new PropertyValueFactory<>("darab"));

        List<Konyv> bookList = KonyvController.getInstance().getAll();
        MainPageTable.setItems(FXCollections.observableList(bookList));
    }

    @FXML
    public void logout(ActionEvent event) {
        Stage stage = LoginController.getMainWindowStage();
        stage.close();

        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/Login.fxml"));
            Scene scene = new Scene(root);
            Stage stage2 = new Stage();
            stage2.setScene(scene);
            stage2.initModality(Modality.APPLICATION_MODAL);
            App.setPrimaryStage(stage2);
            App.getPrimaryStage().show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
