package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.App;
import adatb.konyvesbolt.controller.KonyvController;
import adatb.konyvesbolt.model.Konyv;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;

public class MainPageController implements Initializable {

    @FXML
    private MenuItem bookMenuItem;
    @FXML
    private Button logoutButton;
    @FXML
    private Button tableButton;
    @FXML
    private Button searchButton;
    @FXML
    private TextField searchField;

    @FXML
    private TableView<Konyv> MainPageTable;
    @FXML
    private TableColumn<Konyv, Integer> idCol;
    @FXML
    private TableColumn<Konyv, String> cimCol;
    @FXML
    private TableColumn<Konyv, String> mufajCol;
    @FXML
    private TableColumn<Konyv, String> kiadasiEvCol;
    @FXML
    private TableColumn<Konyv, Integer> arCol;
    @FXML
    private TableColumn<Konyv, Integer> darabCol;

    public MainPageController() {
    }

    @FXML
    public void logout(ActionEvent event) {
        Stage stage = LoginController.getMainWindowStage();
        stage.close();

        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/Login.fxml"));
            Scene scene = new Scene(root);
            Stage stage2 = new Stage();
            stage2.setScene(scene);
            stage2.initModality(Modality.APPLICATION_MODAL);
            App.setPrimaryStage(stage2);
            App.getPrimaryStage().show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void searchBook() {
        String text = "'%" + searchField.getText() + "%'";
        List<Konyv> result = new ArrayList<>();
        if(searchField.getText().isEmpty()) {
            List<Konyv> bookList = KonyvController.getInstance().getAll();
            MainPageTable.setItems(FXCollections.observableList(bookList));
        } else {
            try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
                ResultSet rs = st.executeQuery("SELECT * FROM KONYV WHERE CIM LIKE " + text);

                while (rs.next()) {
                    Konyv k = new Konyv(
                            rs.getInt(1),
                            rs.getString(2),
                            rs.getString(3),
                            rs.getString(4),
                            rs.getInt(5),
                            rs.getInt(6)
                    );
                    result.add(k);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            List<Konyv> bookList = result;
            MainPageTable.setItems(FXCollections.observableList(bookList));
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        idCol.setCellValueFactory(new PropertyValueFactory<>("konyv_id"));
        cimCol.setCellValueFactory(new PropertyValueFactory<>("cim"));
        mufajCol.setCellValueFactory(new PropertyValueFactory<>("mufaj"));
        kiadasiEvCol.setCellValueFactory(new PropertyValueFactory<>("kiadasi_ev"));
        arCol.setCellValueFactory(new PropertyValueFactory<>("ar"));
        darabCol.setCellValueFactory(new PropertyValueFactory<>("darab"));

        List<Konyv> bookList = KonyvController.getInstance().getAll();
        MainPageTable.setItems(FXCollections.observableList(bookList));
    }
}