alter table "BOLTJA" add constraint FK_aruhazBoltja foreign key("ARUHAZNEV") references "ARUHAZ"("ARUHAZ_NEV")
ON DELETE CASCADE ENABLE;

alter table "BOLTJA" add constraint FK_konyvesboltBoltja foreign key("BOLTNEV") references "KONYVESBOLT"("BOLT_NEV")
ON DELETE CASCADE ENABLE;

alter table "ARULJA" add constraint FK_konyvesboltArulja foreign key("BOLTNEV") references "KONYVESBOLT"("BOLT_NEV")
ON DELETE CASCADE ENABLE;

alter table "ARULJA" add constraint FK_konyvArulja foreign key("KONYVID") references "KONYV"("KONYV_ID")
ON DELETE CASCADE ENABLE;

alter table "IRTA" add constraint FK_konyvIrta foreign key("KONYVID") references "KONYV"("KONYV_ID")
ON DELETE CASCADE ENABLE;

alter table "IRTA" add constraint FK_szerzoIrta foreign key("SZERZOID") references "SZERZO"("SZERZO_ID")
ON DELETE CASCADE ENABLE;

alter table "SZERZODTETI" add constraint FK_kiadoSzerzodteti foreign key("KIADONEV") references "KIADO"("KIADO_NEV")
ON DELETE CASCADE ENABLE;

alter table "SZERZODTETI" add constraint FK_szerzoSzerzodteti foreign key("SZERZOID") references "SZERZO"("SZERZO_ID")
ON DELETE CASCADE ENABLE;

alter table "PUBLIKALJA" add constraint FK_kiadoPublikalja foreign key("KIADONEV") references "KIADO"("KIADO_NEV")
ON DELETE CASCADE ENABLE;

alter table "PUBLIKALJA" add constraint FK_konyvPublikalja foreign key("KONYVID") references "KONYV"("KONYV_ID")
ON DELETE CASCADE ENABLE;

alter table "RENDELESIELOZMENYEK" add constraint FK_felhasznaloRE foreign key("FELHASZNALONEV") references "FELHASZNALO"("FELHASZNALO_NEV")
ON DELETE CASCADE ENABLE;

alter table "RENDELESIELOZMENYEK" add constraint FK_konyvRE foreign key("KONYVID") references "KONYV"("KONYV_ID")
ON DELETE CASCADE ENABLE;