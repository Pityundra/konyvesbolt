package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.App;
import adatb.konyvesbolt.dao.FelhasznaloDAO;
import adatb.konyvesbolt.model.Felhasznalo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.List;
import java.util.ResourceBundle;

public class LoginController implements Initializable, FelhasznaloDAO
{

    public static final String DB_STRING = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USER = "SYSTEM";
    public static final String PASSWORD = "kicsinyuszi2000";
    private static final String INSERT_USER = "INSERT INTO FELHASZNALO (FELHASZNALO_NEV, JELSZO, EMAIL_CIM) VALUES " +
            "(?,?,?)";

    @FXML
    private TextField userNameTextField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private TextField emailField;
    @FXML
    private Button regButton;
    @FXML
    private Button loginButton;
    @FXML
    private Label labelEmail;

    private Felhasznalo user = new Felhasznalo();

    @FXML // Regisztrációs gomb event
    public void register(ActionEvent event) {

        Felhasznalo felhasznalo = new Felhasznalo();
        felhasznalo.setFelhasznalo_nev(userNameTextField.getText());
        felhasznalo.setJelszo(passwordField.getText());
        felhasznalo.setEmail(emailField.getText());

        if(UserAlreadyExists(felhasznalo)) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Existing User");
            alert.setHeaderText(null);
            alert.setContentText("Ezzel a felhasználónévvel és/vagy email címmel már létezik felhasználó!");
            alert.showAndWait();
            return;
        }

        if(add(felhasznalo)) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("Regisztráció sikeres!");
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Hiba történt a regisztráció során!");
            alert.showAndWait();
        }

        userNameTextField.setText("");
        passwordField.setText("");
        emailField.setText("");
    }

    @FXML // Bejelentkezés gomb event
    public void login(ActionEvent event) {
        Felhasznalo felhasznalo = new Felhasznalo();
        Stage newStage = new Stage();
        felhasznalo.setFelhasznalo_nev(userNameTextField.getText());
        felhasznalo.setJelszo(passwordField.getText());
        felhasznalo.setEmail(emailField.getText());

        if(ValidUser(felhasznalo, newStage) && felhasznalo.getFelhasznalo_nev().equals("Admin")) {

            Stage stage = App.getPrimaryStage();
            stage.close();

            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/MainPageAdmin.fxml"));
                Scene scene = new Scene(root);
                newStage.setScene(scene);
                newStage.initModality(Modality.APPLICATION_MODAL);
                newStage.showAndWait();

            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if(ValidUser(felhasznalo, newStage)) {

            Stage stage = App.getPrimaryStage();
            stage.close();

            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/MainPage.fxml"));
                Scene scene = new Scene(root);
                newStage.setScene(scene);
                newStage.initModality(Modality.APPLICATION_MODAL);
                newStage.showAndWait();

            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Ilyen felhasználó nem létezik!");
            alert.showAndWait();

            userNameTextField.setText("");
            passwordField.setText("");
            emailField.setText("");
        }
    }


    public LoginController() {
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        user.felhasznalo_nevProperty().bind(userNameTextField.textProperty());
        user.jelszoProperty().bind(passwordField.textProperty());
        user.emailProperty().bind(emailField.textProperty());

        emailField.textProperty().addListener(((observable, oldValue, newValue) -> {
            if(newValue.matches("\\S+@\\S+\\.\\S+")) {
                labelEmail.setText("");
            } else {
                labelEmail.setText("Invalid email.");
            }
        }));

        loginButton.disableProperty().bind(userNameTextField.textProperty().isEmpty()
                .or(labelEmail.textProperty().isNotEmpty()
        .or(passwordField.textProperty().isEmpty())));

        regButton.disableProperty().bind(userNameTextField.textProperty().isEmpty()
                .or(labelEmail.textProperty().isNotEmpty()
                        .or(passwordField.textProperty().isEmpty())));

    }

    @Override
    public boolean add(Felhasznalo f) {
        try(Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD);
            PreparedStatement pst = conn.prepareStatement(INSERT_USER)) {

            pst.setString(1, f.getFelhasznalo_nev());
            pst.setString(2, f.getJelszo());
            pst.setString(3, f.getEmail());

            int res = pst.executeUpdate();
            if(res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean UserAlreadyExists(Felhasznalo f) {
        try(Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD);
            Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM Felhasznalo")) {
            while (rs.next()) {
                Felhasznalo user = new Felhasznalo(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3)
                );
                if(user.getFelhasznalo_nev().equals(f.getFelhasznalo_nev()) || user.getEmail().equals(f.getEmail())) {
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean ValidUser(Felhasznalo f, Stage newStage) {
        try(Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD);
        Statement pst = conn.createStatement();
        ResultSet rs = pst.executeQuery("SELECT * FROM FELHASZNALO")) {

            while (rs.next()) {
                String fnev = rs.getString(1);
                String fjelszo = rs.getString(2);
                String femail = rs.getString(3);

                if(fnev.equals(f.getFelhasznalo_nev()) && fjelszo.equals(f.getJelszo()) && femail.equals(f.getEmail())) {
                    return true;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<Felhasznalo> getAll() {
        return null;
    }
}
