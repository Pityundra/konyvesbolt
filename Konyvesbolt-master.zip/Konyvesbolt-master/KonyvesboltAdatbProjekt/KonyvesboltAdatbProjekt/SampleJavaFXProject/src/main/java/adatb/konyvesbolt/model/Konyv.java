package adatb.konyvesbolt.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Konyv {

    private IntegerProperty id = new SimpleIntegerProperty();
    private StringProperty cim = new SimpleStringProperty();
    private StringProperty mufaj = new SimpleStringProperty();
    private StringProperty kiadasi_ev = new SimpleStringProperty();
    private IntegerProperty ar = new SimpleIntegerProperty();

    public Konyv(StringProperty cim, StringProperty mufaj, StringProperty kiadasi_ev, IntegerProperty ar) {
        this.cim = cim;
        this.mufaj = mufaj;
        this.kiadasi_ev = kiadasi_ev;
        this.ar = ar;
    }

    public Konyv(IntegerProperty id, StringProperty cim, StringProperty mufaj, StringProperty kiadasi_ev, IntegerProperty ar) {
        this.id = id;
        this.cim = cim;
        this.mufaj = mufaj;
        this.kiadasi_ev = kiadasi_ev;
        this.ar = ar;
    }

    public Konyv() {
    }

    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getCim() {
        return cim.get();
    }

    public StringProperty cimProperty() {
        return cim;
    }

    public void setCim(String cim) {
        this.cim.set(cim);
    }

    public String getMufaj() {
        return mufaj.get();
    }

    public StringProperty mufajProperty() {
        return mufaj;
    }

    public void setMufaj(String mufaj) {
        this.mufaj.set(mufaj);
    }

    public String getKiadasi_ev() {
        return kiadasi_ev.get();
    }

    public StringProperty kiadasi_evProperty() {
        return kiadasi_ev;
    }

    public void setKiadasi_ev(String kiadasi_ev) {
        this.kiadasi_ev.set(kiadasi_ev);
    }

    public int getAr() {
        return ar.get();
    }

    public IntegerProperty arProperty() {
        return ar;
    }

    public void setAr(int ar) {
        this.ar.set(ar);
    }

    @Override
    public String toString() {
        return "Konyv{" +
                "id=" + id.get() +
                ", cim=" + cim.get() +
                ", mufaj=" + mufaj.get() +
                ", kiadasi_ev=" + kiadasi_ev.get() +
                ", ar=" + ar.get() +
                '}';
    }
}
