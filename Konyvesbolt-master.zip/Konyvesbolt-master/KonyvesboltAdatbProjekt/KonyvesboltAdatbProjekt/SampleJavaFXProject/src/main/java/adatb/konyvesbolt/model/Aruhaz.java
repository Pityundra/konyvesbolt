package adatb.konyvesbolt.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Aruhaz {

    private IntegerProperty id = new SimpleIntegerProperty();
    private StringProperty aruhaz_nev = new SimpleStringProperty();
    private StringProperty cim_hely = new SimpleStringProperty();

    public Aruhaz(StringProperty aruhaz_nev, StringProperty cim_hely) {
        this.aruhaz_nev = aruhaz_nev;
        this.cim_hely = cim_hely;
    }

    public Aruhaz(IntegerProperty id, StringProperty aruhaz_nev, StringProperty cim_hely) {
        this.id = id;
        this.aruhaz_nev = aruhaz_nev;
        this.cim_hely = cim_hely;
    }

    public Aruhaz() {
    }

    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getAruhaz_nev() {
        return aruhaz_nev.get();
    }

    public StringProperty aruhaz_nevProperty() {
        return aruhaz_nev;
    }

    public void setAruhaz_nev(String aruhaz_nev) {
        this.aruhaz_nev.set(aruhaz_nev);
    }

    public String getCim_hely() {
        return cim_hely.get();
    }

    public StringProperty cim_helyProperty() {
        return cim_hely;
    }

    public void setCim_hely(String cim_hely) {
        this.cim_hely.set(cim_hely);
    }

    @Override
    public String toString() {
        return "Aruhaz{" +
                "id=" + id.get() +
                ", aruhaz_nev=" + aruhaz_nev.get() +
                ", cim_hely=" + cim_hely.get() +
                '}';
    }
}
