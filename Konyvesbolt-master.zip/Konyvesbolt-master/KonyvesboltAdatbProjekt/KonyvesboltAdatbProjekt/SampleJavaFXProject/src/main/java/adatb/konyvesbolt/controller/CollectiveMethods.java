package adatb.konyvesbolt.controller;

public class CollectiveMethods {

    public void tableBooks() {

    }

    public void tableAuthors() {

    }

    public void tablePublishers() {

    }

    public void tableStores() {

    }

    public void tableBookStore() {

    }

    public void search() {

    }
}
