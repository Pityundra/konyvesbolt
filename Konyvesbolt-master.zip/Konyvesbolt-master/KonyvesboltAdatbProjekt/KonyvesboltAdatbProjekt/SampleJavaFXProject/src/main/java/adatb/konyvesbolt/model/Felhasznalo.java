package adatb.konyvesbolt.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Felhasznalo {

    private IntegerProperty id = new SimpleIntegerProperty();
    private StringProperty felhasznalo_nev = new SimpleStringProperty();
    private StringProperty jelszo = new SimpleStringProperty();
    private StringProperty email = new SimpleStringProperty();

    public Felhasznalo(StringProperty felhasznalo_nev, StringProperty jelszo, StringProperty email) {
        this.felhasznalo_nev = felhasznalo_nev;
        this.jelszo = jelszo;
        this.email = email;
    }

    public Felhasznalo(IntegerProperty id, StringProperty felhasznalo_nev, StringProperty jelszo, StringProperty email) {
        this.id = id;
        this.felhasznalo_nev = felhasznalo_nev;
        this.jelszo = jelszo;
        this.email = email;
    }

    public Felhasznalo(String felhasznalo_nev, String jelszo, String email) {
        this.felhasznalo_nev.set(felhasznalo_nev);
        this.jelszo.set(jelszo);
        this.email.set(email);
    }

    public Felhasznalo() {
    }

    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getFelhasznalo_nev() {
        return felhasznalo_nev.get();
    }

    public StringProperty felhasznalo_nevProperty() {
        return felhasznalo_nev;
    }

    public void setFelhasznalo_nev(String felhasznalo_nev) {
        this.felhasznalo_nev.set(felhasznalo_nev);
    }

    public String getJelszo() {
        return jelszo.get();
    }

    public StringProperty jelszoProperty() {
        return jelszo;
    }

    public void setJelszo(String jelszo) {
        this.jelszo.set(jelszo);
    }

    public String getEmail() {
        return email.get();
    }

    public StringProperty emailProperty() {
        return email;
    }

    public void setEmail(String email) {
        this.email.set(email);
    }

    @Override
    public String toString() {
        return "Felhasznalo{" +
                "id=" + id.get() +
                ", felhasznalo_nev=" + felhasznalo_nev.get() +
                ", jelszo=" + jelszo.get() +
                '}';
    }
}
