package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.model.Szerzo;

import java.util.List;

public interface SzerzoDAO {

    public boolean add(Szerzo sz);
    public List<Szerzo> getAll();
}
