package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Felhasznalo;
import adatb.konyvesbolt.model.Konyv;

import java.util.List;

public interface FelhasznaloDAO {

    public boolean add(Felhasznalo f);
    public List<Felhasznalo> getAll();
}
