package adatb.konyvesbolt;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Stage primaryStage;

    static private void setPrimaryStage(Stage stage) {
        App.primaryStage = stage;
    }

    static public Stage getPrimaryStage() {
        return App.primaryStage;
    }

    @Override
    public void start(Stage stage) {
        setPrimaryStage(stage);
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/Login.fxml")); //FXML-ből Java objektumot csinál a loader
        } catch (IOException e) {

            e.printStackTrace();
        }

        try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "SYSTEM", "kicsinyuszi2000");
        ) {
            System.out.println("Most nem szart be ez a progi, wow! :)");
        } catch (SQLException e) {
            System.out.println("Nincs kapcsolat!");
        }

        Scene scene = new Scene(root, 322, 175);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch();
    }

}