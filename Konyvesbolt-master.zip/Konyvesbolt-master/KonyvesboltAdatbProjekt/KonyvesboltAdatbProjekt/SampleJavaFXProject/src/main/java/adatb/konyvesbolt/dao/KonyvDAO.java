package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Konyv;

import java.util.List;

public interface KonyvDAO {

    public boolean add(Konyv k);
    public List<Konyv> getAll();
}
