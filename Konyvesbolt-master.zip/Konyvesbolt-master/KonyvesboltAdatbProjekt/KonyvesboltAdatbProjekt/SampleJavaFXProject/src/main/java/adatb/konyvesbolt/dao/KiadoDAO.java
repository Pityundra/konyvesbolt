package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Kiado;
import adatb.konyvesbolt.model.Konyv;

import java.util.List;

public interface KiadoDAO {

    public boolean add(Kiado kiado);
    public List<Kiado> getAll();
}
