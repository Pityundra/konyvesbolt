package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.model.Konyvesbolt;

import java.util.List;

public interface KonyvesboltDAO {

    public boolean add(Konyvesbolt kb);
    public List<Konyvesbolt> getAll();
}
