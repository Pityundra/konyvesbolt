package adatb.konyvesbolt.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Szerzo {

    private IntegerProperty id = new SimpleIntegerProperty();
    private StringProperty nev = new SimpleStringProperty();

    public Szerzo(StringProperty nev) {
        this.nev = nev;
    }

    public Szerzo(IntegerProperty id, StringProperty nev) {
        this.id = id;
        this.nev = nev;
    }

    public Szerzo() {
    }

    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getNev() {
        return nev.get();
    }

    public StringProperty nevProperty() {
        return nev;
    }

    public void setNev(String nev) {
        this.nev.set(nev);
    }

    @Override
    public String toString() {
        return "Szerzo{" +
                "id=" + id.get() +
                ", nev=" + nev.get() +
                '}';
    }
}
