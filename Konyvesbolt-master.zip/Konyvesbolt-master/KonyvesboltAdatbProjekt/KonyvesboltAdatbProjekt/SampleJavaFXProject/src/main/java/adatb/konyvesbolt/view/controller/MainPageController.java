package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.CollectiveMethods;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;

import java.net.URL;
import java.util.ResourceBundle;

public class MainPageController extends CollectiveMethods implements Initializable {

    @FXML
    private MenuItem bookMenuItem;
    @FXML
    private MenuItem authorMenuItem;
    @FXML
    private MenuItem publisherMenuItem;
    @FXML
    private MenuItem storeMenuItem;
    @FXML
    private MenuItem bookstoreMenuItem;

    public MainPageController() {
    }

    public MenuItem getBookMenuItem() {
        return bookMenuItem;
    }

    public void setBookMenuItem(MenuItem bookMenuItem) {
        this.bookMenuItem = bookMenuItem;
    }

    public MenuItem getAuthorMenuItem() {
        return authorMenuItem;
    }

    public void setAuthorMenuItem(MenuItem authorMenuItem) {
        this.authorMenuItem = authorMenuItem;
    }

    public MenuItem getPublisherMenuItem() {
        return publisherMenuItem;
    }

    public void setPublisherMenuItem(MenuItem publisherMenuItem) {
        this.publisherMenuItem = publisherMenuItem;
    }

    public MenuItem getStoreMenuItem() {
        return storeMenuItem;
    }

    public void setStoreMenuItem(MenuItem storeMenuItem) {
        this.storeMenuItem = storeMenuItem;
    }

    public MenuItem getBookstoreMenuItem() {
        return bookstoreMenuItem;
    }

    public void setBookstoreMenuItem(MenuItem bookstoreMenuItem) {
        this.bookstoreMenuItem = bookstoreMenuItem;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
