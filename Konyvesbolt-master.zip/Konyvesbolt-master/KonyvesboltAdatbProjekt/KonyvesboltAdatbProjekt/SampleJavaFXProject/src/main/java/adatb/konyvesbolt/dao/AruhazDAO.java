package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Aruhaz;
import adatb.konyvesbolt.model.Konyv;

import java.util.List;

public interface AruhazDAO {

    public boolean add(Aruhaz k);
    public List<Aruhaz> getAll();
}
