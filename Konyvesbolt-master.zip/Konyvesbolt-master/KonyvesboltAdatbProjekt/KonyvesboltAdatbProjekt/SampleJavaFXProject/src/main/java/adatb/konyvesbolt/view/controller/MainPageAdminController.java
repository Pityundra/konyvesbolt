package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.CollectiveMethods;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;

import java.net.URL;
import java.util.ResourceBundle;

public class MainPageAdminController extends CollectiveMethods implements Initializable {

    @FXML
    private MenuItem bookMenuItemAdmin;
    @FXML
    private MenuItem authorMenuItemAdmin;
    @FXML
    private MenuItem publisherMenuItemAdmin;
    @FXML
    private MenuItem storeMenuItemAdmin;
    @FXML
    private MenuItem bookstoreMenuItemAdmin;
    @FXML
    private MenuItem userMenuItem;

    public MainPageAdminController() {
    }

    @FXML
    public void addAdmin() {

    }

    @FXML
    public void updateAdmin() {

    }

    @FXML
    public void deleteAdmin() {

    }

    @FXML //ez az FXML lehet nem kell
    public void tableUsers() {

    }

    public MenuItem getBookMenuItemAdmin() {
        return bookMenuItemAdmin;
    }

    public void setBookMenuItemAdmin(MenuItem bookMenuItemAdmin) {
        this.bookMenuItemAdmin = bookMenuItemAdmin;
    }

    public MenuItem getAuthorMenuItemAdmin() {
        return authorMenuItemAdmin;
    }

    public void setAuthorMenuItemAdmin(MenuItem authorMenuItemAdmin) {
        this.authorMenuItemAdmin = authorMenuItemAdmin;
    }

    public MenuItem getPublisherMenuItemAdmin() {
        return publisherMenuItemAdmin;
    }

    public void setPublisherMenuItemAdmin(MenuItem publisherMenuItemAdmin) {
        this.publisherMenuItemAdmin = publisherMenuItemAdmin;
    }

    public MenuItem getStoreMenuItemAdmin() {
        return storeMenuItemAdmin;
    }

    public void setStoreMenuItemAdmin(MenuItem storeMenuItemAdmin) {
        this.storeMenuItemAdmin = storeMenuItemAdmin;
    }

    public MenuItem getBookstoreMenuItemAdmin() {
        return bookstoreMenuItemAdmin;
    }

    public void setBookstoreMenuItemAdmin(MenuItem bookstoreMenuItemAdmin) {
        this.bookstoreMenuItemAdmin = bookstoreMenuItemAdmin;
    }

    public MenuItem getUserMenuItem() {
        return userMenuItem;
    }

    public void setUserMenuItem(MenuItem userMenuItem) {
        this.userMenuItem = userMenuItem;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
    }
}
