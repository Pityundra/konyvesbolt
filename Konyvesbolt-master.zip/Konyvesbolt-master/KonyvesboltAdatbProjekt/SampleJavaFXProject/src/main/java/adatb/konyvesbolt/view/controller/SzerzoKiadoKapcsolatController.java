package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.SzerzoController;
import adatb.konyvesbolt.model.Szerzo;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;

public class SzerzoKiadoKapcsolatController implements Initializable {
    @FXML
    private TableView<Szerzo> MainPageTable;
    @FXML
    private TableColumn<Szerzo, Integer> szerzoIdCol;
    @FXML
    private TableColumn<Szerzo, String> nameCol;

    @FXML
    private TextField searchField;


    public SzerzoKiadoKapcsolatController() {
    }


    @FXML
    public void searchAuthorByPublisher() {
        String text = "'" + searchField.getText() + "'";
        List<Szerzo> result = new ArrayList<>();
        if(searchField.getText().isEmpty()) {
            List<Szerzo> bookList = SzerzoController.getInstance().getAll();
            MainPageTable.setItems(FXCollections.observableList(bookList));
        } else {
            try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
                ResultSet rs = st.executeQuery("SELECT szerzo_id, szerzo_nev FROM Szerzo " +
                        "INNER JOIN Szerzodteti ON szerzo.szerzo_id = szerzodteti.szerzoid " +
                        "AND szerzodteti.kiadonev = (SELECT kiado_nev FROM Kiado WHERE kiado_nev LIKE " + text + ")");

                while (rs.next()) {
                    Szerzo sz = new Szerzo(
                            rs.getInt(1),
                            rs.getString(2)
                    );
                    result.add(sz);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            List<Szerzo> bookList = result;
            MainPageTable.setItems(FXCollections.observableList(bookList));
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        szerzoIdCol.setCellValueFactory(new PropertyValueFactory<>("szerzo_id"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("szerzo_nev"));

        List<Szerzo> bookList = SzerzoController.getInstance().getAll();
        MainPageTable.setItems(FXCollections.observableList(bookList));
    }

}
