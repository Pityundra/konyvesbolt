package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.App;
import adatb.konyvesbolt.controller.KonyvController;
import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.ResourceBundle;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;

public class MainPageController implements Initializable {

    @FXML
    private MenuItem bookMenuItem;
    @FXML
    private Button logoutButton;
    @FXML
    private Button tableButton;
    @FXML
    private Button searchButton;
    @FXML
    private TextField searchField;

    @FXML
    private TableView<Konyv> MainPageTable;
    @FXML
    private TableColumn<Konyv, Integer> idCol;
    @FXML
    private TableColumn<Konyv, String> cimCol;
    @FXML
    private TableColumn<Konyv, String> mufajCol;
    @FXML
    private TableColumn<Konyv, String> kiadasiEvCol;
    @FXML
    private TableColumn<Konyv, Integer> arCol;
    @FXML
    private TableColumn<Konyv, Integer> darabCol;

    public List<Konyv> bookList;
    File checkFile = new File("C:\\Programozas\\Java\\JavaFX\\KonyvesboltAdatbProjekt\\SampleJavaFXProject\\check.txt");

    @FXML
    private TextField buyCountField;

    @FXML
    private Button searchAuthorButton;
    @FXML
    private TextField searchAuthorField;

    @FXML
    private Button searchPublisherButton;
    @FXML
    private TextField searchPublisherField;

    @FXML
    private Button searchBookStoreButton;
    @FXML
    private TextField searchBookStoreField;

    public MainPageController() {
    }

    public void refreshTable(){
        bookList = KonyvController.getInstance().getAll();
        MainPageTable.setItems(FXCollections.observableList(bookList));
    }

    @FXML
    public void logout(ActionEvent event) {
        Stage stage = LoginController.getMainWindowStage();
        stage.close();

        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/Login.fxml"));
            Scene scene = new Scene(root);
            Stage stage2 = new Stage();
            stage2.setScene(scene);
            stage2.initModality(Modality.APPLICATION_MODAL);
            App.setPrimaryStage(stage2);
            App.getPrimaryStage().show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void searchBook() {
        String text = "'%" + searchField.getText() + "%'";
        List<Konyv> result = new ArrayList<>();
        if(searchField.getText().isEmpty()) {
            refreshTable();
        } else {
            try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
                ResultSet rs = st.executeQuery("SELECT * FROM KONYV WHERE CIM LIKE " + text);

                while (rs.next()) {
                    Konyv k = new Konyv(
                            rs.getInt(1),
                            rs.getString(2),
                            rs.getString(3),
                            rs.getString(4),
                            rs.getInt(5),
                            rs.getInt(6)
                    );
                    result.add(k);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            bookList = result;
            MainPageTable.setItems(FXCollections.observableList(bookList));
        }
    }

    @FXML
    public void purchaseBook() {
        Konyv k = MainPageTable.getSelectionModel().getSelectedItem();
        if(createCheckForPayment(k)) {
            System.out.println("Check works!");
            if(reduceBookCount(k)) {
                if(insertHistory(k))
                AlertsForUser.successAlert("A könyv(ek) vásárlása sikeres volt!");
            }
        }
    }

    public boolean insertHistory(Konyv k) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement st = conn.prepareStatement("INSERT INTO" +
                " RENDELESIELOZMENYEK(felhasznalonev, konyvid) VALUES " +
                "(?,?)")) {
            st.setString(1, LoginController.currentOnlineUser.getFelhasznalo_nev());
            st.setInt(2, k.getKonyv_id());

            int res = st.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    private boolean reduceBookCount(Konyv k) {
        int buyBookCount = Integer.parseInt(buyCountField.getText());
        if((k.getDarab() - buyBookCount) == 0) {
            KonyvController.getInstance().delete(k);
            refreshTable();
        } else if(k.getDarab() - buyBookCount < 0) {
            AlertsForUser.errorAlert("Nincs ennyi könyv a raktáron!");
            return false;
        } else {
            try(Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement pt = conn.prepareStatement("UPDATE" +
                    " KONYV SET DARAB = ? WHERE CIM = ?")) {

                pt.setInt(1, (k.getDarab() - buyBookCount));
                pt.setString(2, k.getCim());


                int res = pt.executeUpdate();
                if (res == 1) {
                    refreshTable();
                    return true;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return false;
        }
        return true;
    }

    private boolean createCheckForPayment(Konyv k) {
        int buyBookCount = Integer.parseInt(buyCountField.getText());
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        try(FileWriter myWriter = new FileWriter(checkFile)) {
                myWriter.write("-- Számla --\n" +
                        "Cím: " + k.getCim() + "\n" +
                        "Darabszám:" +
                        " " + buyBookCount + "\n" +
                        "Teljes ár: " + k.getAr()*buyBookCount + " ft\n" +
                        "====================\n" +
                        "Vásárlás időpontja: " + LocalDateTime.now().format(format) + "\n" +
                        "====================\n" +
                        "Köszönjük, hogy nálunk vásárolt!");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }

    @FXML
    public void searchByAuthor() {
        List<Konyv> listByAuthor = new ArrayList<>();
        String szerzoNev = "'" + searchAuthorField.getText() + "'";

        if(searchAuthorField.getText().isEmpty()) {
            refreshTable();
        } else {
            try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD);
                 Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery("SELECT konyv_id, cim, mufaj, kiadasi_ev, ar, darab FROM Konyv " +
                         "INNER JOIN Irta ON Konyv.konyv_id = irta.konyvid " +
                         "AND irta.szerzoid = (SELECT szerzo_id FROM Szerzo WHERE szerzo_nev = " + szerzoNev + ")")) {

                while (rs.next()) {
                    Konyv k = new Konyv(
                            rs.getInt(1),
                            rs.getString(2),
                            rs.getString(3),
                            rs.getString(4),
                            rs.getInt(5),
                            rs.getInt(6)
                    );
                    listByAuthor.add(k);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            MainPageTable.setItems(FXCollections.observableList(listByAuthor));
        }
    }

    @FXML
    public void searchByPublisher() {
        List<Konyv> listByPublisher = new ArrayList<>();
        String kiadoNev = "'" + searchPublisherField.getText() + "'";

        if(searchPublisherField.getText().isEmpty()) {
            refreshTable();
        } else {
            try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD);
                 Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery("SELECT konyv_id, cim, mufaj, kiadasi_ev, ar, darab FROM Konyv " +
                         "INNER JOIN Publikalja ON Konyv.konyv_id = publikalja.konyvid " +
                         "AND publikalja.kiadonev = " +
                         "(SELECT kiado_nev FROM Kiado WHERE kiado_nev LIKE " + kiadoNev + ")")) {

                while (rs.next()) {
                    Konyv k = new Konyv(
                            rs.getInt(1),
                            rs.getString(2),
                            rs.getString(3),
                            rs.getString(4),
                            rs.getInt(5),
                            rs.getInt(6)
                    );
                    listByPublisher.add(k);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            MainPageTable.setItems(FXCollections.observableList(listByPublisher));
        }
    }

    @FXML
    public void searchByBookStore() {
        List<Konyv> listByBookStore = new ArrayList<>();
        String boltNev = "'" + searchBookStoreField.getText() + "'";

        if(searchBookStoreField.getText().isEmpty()) {
            refreshTable();
        } else {
            try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD);
                 Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery("SELECT konyv_id, cim, mufaj, kiadasi_ev, ar, darab FROM Konyv " +
                         "INNER JOIN Arulja ON Konyv.konyv_id = arulja.konyvid " +
                         "AND arulja.boltnev = " +
                         "(SELECT bolt_nev FROM Konyvesbolt WHERE bolt_nev LIKE " + boltNev + ")")) {

                while (rs.next()) {
                    Konyv k = new Konyv(
                            rs.getInt(1),
                            rs.getString(2),
                            rs.getString(3),
                            rs.getString(4),
                            rs.getInt(5),
                            rs.getInt(6)
                    );
                    listByBookStore.add(k);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            MainPageTable.setItems(FXCollections.observableList(listByBookStore));
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        idCol.setCellValueFactory(new PropertyValueFactory<>("konyv_id"));
        cimCol.setCellValueFactory(new PropertyValueFactory<>("cim"));
        mufajCol.setCellValueFactory(new PropertyValueFactory<>("mufaj"));
        kiadasiEvCol.setCellValueFactory(new PropertyValueFactory<>("kiadasi_ev"));
        arCol.setCellValueFactory(new PropertyValueFactory<>("ar"));
        darabCol.setCellValueFactory(new PropertyValueFactory<>("darab"));

        bookList = KonyvController.getInstance().getAll();
        MainPageTable.setItems(FXCollections.observableList(bookList));

        try {
            checkFile.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}