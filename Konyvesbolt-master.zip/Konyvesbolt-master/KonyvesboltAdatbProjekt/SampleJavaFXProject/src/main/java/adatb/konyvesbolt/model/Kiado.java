package adatb.konyvesbolt.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Kiado {

    private IntegerProperty id = new SimpleIntegerProperty();
    private StringProperty kiado_nev = new SimpleStringProperty();

    public Kiado(String kiado_nev) {
        this.kiado_nev.set(kiado_nev);
    }

    public Kiado(int id, String kiado_nev) {
        this.id.set(id);
        this.kiado_nev.set(kiado_nev);
    }

    public Kiado() {
    }

    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getKiado_nev() {
        return kiado_nev.get();
    }

    public StringProperty kiado_nevProperty() {
        return kiado_nev;
    }

    public void setKiado_nev(String kiado_nev) {
        this.kiado_nev.set(kiado_nev);
    }

    @Override
    public String toString() {
        return "Kiado{" +
                "id=" + id.get() +
                ", kiado_nev=" + kiado_nev.get() +
                '}';
    }
}
