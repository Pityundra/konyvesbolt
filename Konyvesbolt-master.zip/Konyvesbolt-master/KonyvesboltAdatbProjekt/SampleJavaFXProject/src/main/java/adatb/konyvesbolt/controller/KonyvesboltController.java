package adatb.konyvesbolt.controller;

import adatb.konyvesbolt.dao.KonyvesboltDAO;
import adatb.konyvesbolt.dao.KonyvesboltDaoImpl;
import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.model.Konyvesbolt;
import javafx.scene.control.TableView;

import java.util.List;

public class KonyvesboltController {
    private KonyvesboltDAO dao = new KonyvesboltDaoImpl();

    private static KonyvesboltController instance;

    public static KonyvesboltController getInstance() {
        if(instance == null) {
            instance = new KonyvesboltController();
        }
        return instance;
    }

    private KonyvesboltController() {
    }

    public boolean add(Konyvesbolt kb) {
        return dao.add(kb);
    }

    public List<Konyvesbolt> getAll() {
        return dao.getAll();
    }

    public boolean delete(Konyvesbolt kb) {
        return dao.delete(kb);
    }

    public boolean update(Konyvesbolt kb, Konyvesbolt old) {
        return dao.update(kb, old);
    }
}
