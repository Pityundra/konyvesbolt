package adatb.konyvesbolt.controller;

import adatb.konyvesbolt.dao.SzerzoDAO;
import adatb.konyvesbolt.dao.SzerzoDaoImpl;
import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.model.Szerzo;
import javafx.scene.control.TableView;

import java.util.List;

public class SzerzoController {
    private SzerzoDAO dao = new SzerzoDaoImpl();

    private static SzerzoController instance;

    public static SzerzoController getInstance() {
        if(instance == null) {
            instance = new SzerzoController();
        }
        return instance;
    }

    private SzerzoController() {
    }

    public boolean add(Szerzo sz) {
        return dao.add(sz);
    }

    public List<Szerzo> getAll() {
        return dao.getAll();
    }

    public boolean delete(Szerzo sz) {
        return dao.delete(sz);
    }

    public boolean update(Szerzo sz, Szerzo old) {
        return dao.update(sz, old);
    }
}
