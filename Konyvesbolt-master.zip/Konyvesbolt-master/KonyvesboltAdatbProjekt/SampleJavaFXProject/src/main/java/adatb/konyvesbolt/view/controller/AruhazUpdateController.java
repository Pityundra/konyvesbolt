package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.AruhazController;
import adatb.konyvesbolt.controller.SzerzoController;
import adatb.konyvesbolt.model.Aruhaz;
import adatb.konyvesbolt.model.Szerzo;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class AruhazUpdateController implements Initializable {
    @FXML
    private TextField nevField;
    @FXML
    private TextField cimHelyField;

    @FXML
    private Button okButton;

    public AruhazUpdateController() {
    }

    @FXML
    public void update(ActionEvent event) {

        Aruhaz aruhazOld = AruhazAdminController.oldAruhaz;

        Aruhaz aruhazNew = new Aruhaz();
        aruhazNew.setAruhaz_nev(nevField.getText());
        aruhazNew.setCim_hely(cimHelyField.getText());

        if(AruhazController.getInstance().update(aruhazNew, aruhazOld)) {
            AlertsForUser.successAlert("Sikerült az áruház frissítése!");
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        } else {
            AlertsForUser.errorAlert("Hiba történt az áruház frissítése során!");
            return;
        }
    }

    @FXML
    public void cancel(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
