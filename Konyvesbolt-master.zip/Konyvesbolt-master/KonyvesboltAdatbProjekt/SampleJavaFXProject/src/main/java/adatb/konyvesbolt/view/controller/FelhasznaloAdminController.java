package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.AruhazController;
import adatb.konyvesbolt.controller.FelhasznaloController;
import adatb.konyvesbolt.model.Aruhaz;
import adatb.konyvesbolt.model.Felhasznalo;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;

public class FelhasznaloAdminController implements Initializable {
    @FXML
    private TableView<Felhasznalo> MainPageTable;
    @FXML
    private TableColumn<Felhasznalo, String> nevCol;
    @FXML
    private TableColumn<Felhasznalo, String> jelszoCol;
    @FXML
    private TableColumn<Felhasznalo, String> emailCol;

    @FXML
    private TextField searchField;

    public static Felhasznalo oldFelhasznalo;

    public FelhasznaloAdminController() {
    }

    @FXML
    public void addFelhasznaloAdmin() {

        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/FelhasznaloAdd.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void updateFelhasznaloAdmin() {

        Parent root = null;
        oldFelhasznalo = MainPageTable.getSelectionModel().getSelectedItem();
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/FelhasznaloUpdate.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void deleteFelhasznaloAdmin() {
        Felhasznalo f = MainPageTable.getSelectionModel().getSelectedItem();
        int selectedIndex = MainPageTable.getSelectionModel().getSelectedIndex();

        if (selectedIndex >= 0) {
            Optional<ButtonType> result = AlertsForUser.confirmationAlert("Biztos, hogy törlöd a kiválasztott felhasználót?");
            if(result.get() == ButtonType.OK) {
                FelhasznaloController.getInstance().delete(f);
                MainPageTable.getItems().remove(selectedIndex);
            }
        }
    }

    @FXML
    public void searchFelhasznalo() {
        String text = "'%" + searchField.getText() + "%'";
        List<Felhasznalo> result = new ArrayList<>();
        if(searchField.getText().isEmpty()) {
            List<Felhasznalo> bookList = FelhasznaloController.getInstance().getAll();
            MainPageTable.setItems(FXCollections.observableList(bookList));
        } else {
            try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
                ResultSet rs = st.executeQuery("SELECT * FROM FELHASZNALO WHERE FELHASZNALO_NEV LIKE " + text);

                while (rs.next()) {
                    Felhasznalo f = new Felhasznalo(
                            rs.getString(1),
                            rs.getString(2),
                            rs.getString(3)
                    );
                    result.add(f);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            List<Felhasznalo> bookList = result;
            MainPageTable.setItems(FXCollections.observableList(bookList));
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        nevCol.setCellValueFactory(new PropertyValueFactory<>("felhasznalo_nev"));
        jelszoCol.setCellValueFactory(new PropertyValueFactory<>("jelszo"));
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));

        List<Felhasznalo> bookList = FelhasznaloController.getInstance().getAll();
        MainPageTable.setItems(FXCollections.observableList(bookList));
    }
}
