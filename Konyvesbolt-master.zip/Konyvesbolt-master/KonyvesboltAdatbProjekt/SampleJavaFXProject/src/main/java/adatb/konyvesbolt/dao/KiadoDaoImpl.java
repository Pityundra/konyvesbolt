package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Kiado;
import adatb.konyvesbolt.model.Konyvesbolt;
import javafx.scene.control.TableView;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;

public class KiadoDaoImpl implements KiadoDAO {
    @Override
    public boolean add(Kiado kiado) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement st = conn.prepareStatement(INSERT_KIADO)) {
            st.setString(1, kiado.getKiado_nev());
            int res = st.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public List<Kiado> getAll() {
        List<Kiado> result = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery(SELECT_KIADO);

            while (rs.next()) {
                Kiado ki = new Kiado(
                        rs.getString(1)
                );
                result.add(ki);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean delete(Kiado kiado) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement pt = conn.prepareStatement("DELETE " +
                "FROM KIADO WHERE KIADO_NEV LIKE ?")) {

            pt.setString(1, kiado.getKiado_nev());

            int res = pt.executeUpdate();
            if (res == 1) {
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean update(Kiado kiado, Kiado old) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement pt = conn.prepareStatement("UPDATE" +
                " KIADO SET KIADO_NEV = ? WHERE KIADO_NEV = ?")) {

            pt.setString(1, kiado.getKiado_nev());
            pt.setString(2, old.getKiado_nev());

            int res = pt.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}