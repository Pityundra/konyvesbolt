package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.model.Konyvesbolt;
import javafx.scene.control.TableView;

import java.util.List;

public interface KonyvesboltDAO {

    public boolean add(Konyvesbolt kb);
    public List<Konyvesbolt> getAll();
    public boolean delete(Konyvesbolt kb);
    public boolean update(Konyvesbolt kb, Konyvesbolt old);
}
