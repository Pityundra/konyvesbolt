package adatb.konyvesbolt;

import adatb.konyvesbolt.dao.DatabaseStrings;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Stage primaryStage;

    static public void setPrimaryStage(Stage stage) {
        App.primaryStage = stage;
    }

    static public Stage getPrimaryStage() {
        return App.primaryStage;
    }

    @Override
    public void start(Stage stage) {
        setPrimaryStage(stage);
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/Login.fxml")); //FXML-ből Java objektumot csinál a loader
        } catch (IOException e) {

            e.printStackTrace();
        }

        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD);
        ) {
        } catch (SQLException e) {
        }

        Scene scene = new Scene(root, 322, 175);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch();
    }

}