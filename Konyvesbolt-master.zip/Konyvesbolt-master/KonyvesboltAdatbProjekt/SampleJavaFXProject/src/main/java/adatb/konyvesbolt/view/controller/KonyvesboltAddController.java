package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.KonyvController;
import adatb.konyvesbolt.controller.KonyvesboltController;
import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.model.Konyvesbolt;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class KonyvesboltAddController implements Initializable {
    @FXML
    private TextField nameField;

    @FXML
    private Button okButton;

    public KonyvesboltAddController() {
    }

    @FXML
    public void save(ActionEvent event) {

        Konyvesbolt kb = new Konyvesbolt();
        kb.setBolt_nev(nameField.getText());

        if (KonyvesboltController.getInstance().add(kb)) {
            AlertsForUser.successAlert("Sikerült a könyvesbolt hozzáadása!");
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        } else {
            AlertsForUser.errorAlert("Hiba történt a könyvesbolt hozzáaadása során!");
            return;
        }
    }

    @FXML
    public void cancel(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
