package adatb.konyvesbolt.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Szerzo {

    private IntegerProperty szerzo_id = new SimpleIntegerProperty();
    private StringProperty szerzo_nev = new SimpleStringProperty();

    public Szerzo(String szerzo_nev) {
        this.szerzo_nev.set(szerzo_nev);
    }

    public Szerzo(int szerzo_id, String szerzo_nev) {
        this.szerzo_id.set(szerzo_id);
        this.szerzo_nev.set(szerzo_nev);
    }

    public Szerzo() {
    }

    public int getSzerzo_id() {
        return szerzo_id.get();
    }

    public IntegerProperty szerzo_idProperty() {
        return szerzo_id;
    }

    public void setSzerzo_id(int szerzo_id) {
        this.szerzo_id.set(szerzo_id);
    }

    public String getSzerzo_nev() {
        return szerzo_nev.get();
    }

    public StringProperty szerzo_nevProperty() {
        return szerzo_nev;
    }

    public void setSzerzo_nev(String szerzo_nev) {
        this.szerzo_nev.set(szerzo_nev);
    }

    @Override
    public String toString() {
        return "Szerzo{" +
                "id=" + szerzo_id.get() +
                ", nev=" + szerzo_nev.get() +
                '}';
    }
}
