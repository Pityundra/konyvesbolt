package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Kiado;
import javafx.scene.control.TableView;

import java.util.List;

public interface KiadoDAO {

    public boolean add(Kiado kiado);
    public List<Kiado> getAll();
    public boolean delete(Kiado kiado);
    public boolean update(Kiado kiado, Kiado old);
}
