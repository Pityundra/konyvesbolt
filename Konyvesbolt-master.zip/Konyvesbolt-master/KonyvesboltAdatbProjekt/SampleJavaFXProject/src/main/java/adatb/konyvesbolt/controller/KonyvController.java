package adatb.konyvesbolt.controller;

import adatb.konyvesbolt.dao.KonyvDAO;
import adatb.konyvesbolt.dao.KonyvDaoImpl;
import adatb.konyvesbolt.model.Konyv;
import javafx.scene.control.TableView;

import java.util.List;

public class KonyvController {

    private KonyvDAO dao = new KonyvDaoImpl();

    private static KonyvController instance;

    public static KonyvController getInstance() {
        if(instance == null) {
            instance = new KonyvController();
        }
        return instance;
    }

    private KonyvController() {
    }

    public boolean add(Konyv k) {
        return dao.add(k);
    }

    public List<Konyv> getAll() {
        return dao.getAll();
    }

    public boolean delete(Konyv k) {
        return dao.delete(k);
    }

    public boolean update(Konyv k, Konyv old) {
        return dao.update(k, old);
    }
}
