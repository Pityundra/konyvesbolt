package adatb.konyvesbolt.controller;

import adatb.konyvesbolt.model.Konyv;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;

public class CollectiveMethods {

    public void tableBooks() {

    }

    public void tableAuthors() {

    }

    public void tablePublishers() {

    }

    public void tableStores() {

    }

    public void tableBookStore() {

    }
}
