package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Konyv;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;

public class KonyvDaoImpl implements KonyvDAO {

    @Override
    public boolean add(Konyv k) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement st = conn.prepareStatement(INSERT_KONYV)) {
            st.setInt(1, k.getKonyv_id());
            st.setString(2, k.getCim());
            st.setString(3, k.getMufaj());
            st.setString(4, k.getKiadasi_ev());
            st.setInt(5, k.getAr());
            st.setInt(6, k.getDarab());
            int res = st.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public List<Konyv> getAll() {
        List<Konyv> result = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery(SELECT_KONYV);

            while (rs.next()) {
                Konyv k = new Konyv(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getInt(5),
                        rs.getInt(6)
                );
                result.add(k);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean delete(Konyv k) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement pt = conn.prepareStatement("DELETE " +
                "FROM KONYV WHERE CIM LIKE ?")) {

            pt.setString(1, k.getCim());

            int res = pt.executeUpdate();
            if (res == 1) {
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean update(Konyv k, Konyv old) {
        try(Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement pt = conn.prepareStatement("UPDATE" +
                " KONYV SET KONYV_ID = ?, CIM = ?, MUFAJ = ?, KIADASI_EV = ?, AR = ?, DARAB = ? WHERE" +
                " CIM = ?")) {

            pt.setInt(1, k.getKonyv_id());
            pt.setString(2, k.getCim());
            pt.setString(3, k.getMufaj());
            pt.setString(4, k.getKiadasi_ev());
            pt.setInt(5, k.getAr());
            pt.setInt(6, k.getDarab());
            pt.setString(7, old.getCim());

            int res = pt.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
