package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.model.Szerzo;
import javafx.scene.control.TableView;

import java.util.List;

public interface SzerzoDAO {

    public boolean add(Szerzo sz);
    public List<Szerzo> getAll();
    public boolean delete(Szerzo sz);
    public boolean update(Szerzo sz, Szerzo old);
}
