package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.AruhazController;
import adatb.konyvesbolt.model.Aruhaz;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;

public class KonyvesboltAruhazKapcsolatController implements Initializable {
    @FXML
    private TableView<Aruhaz> MainPageTable;
    @FXML
    private TableColumn<Aruhaz, String> nevCol;
    @FXML
    private TableColumn<Aruhaz, String> cimHelyCol;

    @FXML
    private TextField searchField;

    public KonyvesboltAruhazKapcsolatController() {
    }


    @FXML
    public void searchStoreByBookStore() {
        String text = "'" + searchField.getText() + "'";
        List<Aruhaz> result = new ArrayList<>();
        if(searchField.getText().isEmpty()) {
            List<Aruhaz> bookList = AruhazController.getInstance().getAll();
            MainPageTable.setItems(FXCollections.observableList(bookList));
        } else {
            try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
                ResultSet rs = st.executeQuery("SELECT aruhaz_nev, cim_hely FROM Aruhaz " +
                        "INNER JOIN Boltja ON aruhaz.aruhaz_nev = boltja.aruhaznev " +
                        "AND boltja.boltnev = (SELECT bolt_nev FROM Konyvesbolt WHERE bolt_nev LIKE " + text + ")");

                while (rs.next()) {
                    Aruhaz a = new Aruhaz(
                            rs.getString(1),
                            rs.getString(2)
                    );
                    result.add(a);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            List<Aruhaz> bookList = result;
            MainPageTable.setItems(FXCollections.observableList(bookList));
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        nevCol.setCellValueFactory(new PropertyValueFactory<>("aruhaz_nev"));
        cimHelyCol.setCellValueFactory(new PropertyValueFactory<>("cim_hely"));

        List<Aruhaz> bookList = AruhazController.getInstance().getAll();
        MainPageTable.setItems(FXCollections.observableList(bookList));
    }
}
