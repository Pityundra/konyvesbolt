package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Aruhaz;
import adatb.konyvesbolt.model.Felhasznalo;
import javafx.scene.control.TableView;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;

public class FelhasznaloDaoImpl implements FelhasznaloDAO {
    @Override
    public boolean add(Felhasznalo f) {
        try(Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD);
            PreparedStatement pst = conn.prepareStatement(INSERT_FELHASZNALO)) {

            pst.setString(1, f.getFelhasznalo_nev());
            pst.setString(2, f.getJelszo());
            pst.setString(3, f.getEmail());

            int res = pst.executeUpdate();
            if(res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<Felhasznalo> getAll() {
        List<Felhasznalo> result = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery(SELECT_FELHASZNALO);

            while (rs.next()) {
                Felhasznalo f = new Felhasznalo(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3)
                );
                result.add(f);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean delete(Felhasznalo f) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement pt = conn.prepareStatement("DELETE " +
                "FROM FELHASZNALO WHERE FELHASZNALO_NEV LIKE ?")) {

            pt.setString(1, f.getFelhasznalo_nev());

            int res = pt.executeUpdate();
            if (res == 1) {
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean update(Felhasznalo f, Felhasznalo old) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement pt = conn.prepareStatement("UPDATE" +
                " FELHASZNALO SET FELHASZNALO_NEV = ?, JELSZO = ?, EMAIL_CIM = ? WHERE FELHASZNALO_NEV = ?")) {

            pt.setString(1, f.getFelhasznalo_nev());
            pt.setString(2, f.getJelszo());
            pt.setString(3, f.getEmail());
            pt.setString(4, old.getFelhasznalo_nev());

            int res = pt.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
