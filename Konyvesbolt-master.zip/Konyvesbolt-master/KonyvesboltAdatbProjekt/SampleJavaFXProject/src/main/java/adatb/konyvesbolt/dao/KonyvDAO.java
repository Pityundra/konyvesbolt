package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Konyv;
import javafx.scene.control.TableView;

import java.util.List;

public interface KonyvDAO {

    public boolean add(Konyv k);
    public List<Konyv> getAll();
    public boolean delete(Konyv k);
    public boolean update(Konyv k, Konyv old);
}
