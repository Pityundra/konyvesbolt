package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Aruhaz;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.scene.control.TableView;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;

public class AruhazDaoImpl implements AruhazDAO {

    public AruhazDaoImpl() {
    }

    @Override
    public boolean add(Aruhaz a) {
        try(Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD);
            PreparedStatement pst = conn.prepareStatement(INSERT_ARUHAZ)) {
            pst.setString(1, a.getAruhaz_nev());
            pst.setString(2, a.getCim_hely());

            int res = pst.executeUpdate();
            if(res == 1) return true;

        } catch (SQLException e) {
            AlertsForUser.errorAlert("Hiba történt az áruház hozzáadásánál!");
        }
        return false;
    }

    @Override
    public List<Aruhaz> getAll() {
        List<Aruhaz> result = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery(SELECT_ARUHAZ);

            while (rs.next()) {
                Aruhaz a = new Aruhaz(
                        rs.getString(1),
                        rs.getString(2)
                );
                result.add(a);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }


    @Override
    public boolean delete(Aruhaz a) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement pt = conn.prepareStatement("DELETE " +
                "FROM ARUHAZ WHERE ARUHAZ_NEV LIKE ?")) {

            pt.setString(1, a.getAruhaz_nev());

            int res = pt.executeUpdate();
            if (res == 1) {
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean update(Aruhaz a, Aruhaz old) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement pt = conn.prepareStatement("UPDATE" +
                " ARUHAZ SET ARUHAZ_NEV = ?, CIM_HELY = ? WHERE ARUHAZ_NEV = ?")) {

            pt.setString(1, a.getAruhaz_nev());
            pt.setString(2, a.getCim_hely());
            pt.setString(3, old.getAruhaz_nev());

            int res = pt.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}

