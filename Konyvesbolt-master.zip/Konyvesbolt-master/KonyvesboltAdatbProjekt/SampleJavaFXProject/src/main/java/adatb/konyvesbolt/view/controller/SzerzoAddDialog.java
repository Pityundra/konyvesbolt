package adatb.konyvesbolt.view.controller;

public class SzerzoAddDialog {
}
