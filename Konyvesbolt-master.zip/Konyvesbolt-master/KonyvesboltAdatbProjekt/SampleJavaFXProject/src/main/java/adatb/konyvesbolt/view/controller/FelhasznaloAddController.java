package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.AruhazController;
import adatb.konyvesbolt.controller.FelhasznaloController;
import adatb.konyvesbolt.model.Aruhaz;
import adatb.konyvesbolt.model.Felhasznalo;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class FelhasznaloAddController implements Initializable {
    @FXML
    private TextField nevField;
    @FXML
    private TextField jelszoField;
    @FXML
    private TextField emailField;

    @FXML
    private Button okButton;

    public FelhasznaloAddController() {
    }

    @FXML
    public void save(ActionEvent event) {

        Felhasznalo f = new Felhasznalo();
        f.setFelhasznalo_nev(nevField.getText());
        f.setJelszo(jelszoField.getText());
        f.setEmail(emailField.getText());

        if (FelhasznaloController.getInstance().add(f)) {
            AlertsForUser.successAlert("Sikerült a felhasználó hozzáadása!");
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        } else {
            AlertsForUser.errorAlert("Hiba történt a felhasználó hozzáadása során!");
            return;
        }
    }

    @FXML
    public void cancel(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
