package adatb.konyvesbolt.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Konyvesbolt {

    private IntegerProperty id = new SimpleIntegerProperty();
    private StringProperty bolt_nev = new SimpleStringProperty();

    public Konyvesbolt(String bolt_nev) {
        this.bolt_nev.set(bolt_nev);
    }

    public Konyvesbolt(int id, String bolt_nev) {
        this.id.set(id);
        this.bolt_nev.set(bolt_nev);
    }

    public Konyvesbolt() {
    }

    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getBolt_nev() {
        return bolt_nev.get();
    }

    public StringProperty bolt_nevProperty() {
        return bolt_nev;
    }

    public void setBolt_nev(String bolt_nev) {
        this.bolt_nev.set(bolt_nev);
    }

    @Override
    public String toString() {
        return "Konyvesbolt{" +
                "id=" + id.get() +
                ", bolt_nev=" + bolt_nev.get() +
                '}';
    }
}
