package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.KiadoController;
import adatb.konyvesbolt.controller.KonyvesboltController;
import adatb.konyvesbolt.model.Kiado;
import adatb.konyvesbolt.model.Konyvesbolt;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class KiadoAddController implements Initializable {
    @FXML
    private TextField nameField;

    @FXML
    private Button okButton;

    public KiadoAddController() {
    }

    @FXML
    public void save(ActionEvent event) {

        Kiado ki = new Kiado();
        ki.setKiado_nev(nameField.getText());

        if (KiadoController.getInstance().add(ki)) {
            AlertsForUser.successAlert("Sikerült a kiadó hozzáadása!");
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        } else {
            AlertsForUser.errorAlert("Hiba történt a kiadó hozzáaadása során!");
            return;
        }
    }

    @FXML
    public void cancel(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
