package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.AruhazController;
import adatb.konyvesbolt.controller.SzerzoController;
import adatb.konyvesbolt.model.Aruhaz;
import adatb.konyvesbolt.model.Szerzo;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;

public class AruhazAdminController implements Initializable {
    @FXML
    private TableView<Aruhaz> MainPageTable;
    @FXML
    private TableColumn<Aruhaz, String> nevCol;
    @FXML
    private TableColumn<Aruhaz, String> cimHelyCol;

    @FXML
    private TextField searchField;

    public static Aruhaz oldAruhaz;

    public AruhazAdminController() {
    }

    @FXML
    public void addAruhazAdmin() {

        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/AruhazAdd.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void updateAruhazAdmin() {

        Parent root = null;
        oldAruhaz = MainPageTable.getSelectionModel().getSelectedItem();
        try {
            root = FXMLLoader.load(getClass().getResource("/adatb.konyvesbolt.view/AruhazUpdate.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void deleteAruhazAdmin() {
        Aruhaz a = MainPageTable.getSelectionModel().getSelectedItem();
        int selectedIndex = MainPageTable.getSelectionModel().getSelectedIndex();

        if (selectedIndex >= 0) {
            Optional<ButtonType> result = AlertsForUser.confirmationAlert("Biztos, hogy törlöd a kiválasztott áruházat?");
            if(result.get() == ButtonType.OK) {
                AruhazController.getInstance().delete(a);
                MainPageTable.getItems().remove(selectedIndex);
            }
        }
    }

    @FXML
    public void searchAruhaz() {
        String text = "'%" + searchField.getText() + "%'";
        List<Aruhaz> result = new ArrayList<>();
        if(searchField.getText().isEmpty()) {
            List<Aruhaz> bookList = AruhazController.getInstance().getAll();
            MainPageTable.setItems(FXCollections.observableList(bookList));
        } else {
            try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
                ResultSet rs = st.executeQuery("SELECT * FROM ARUHAZ WHERE ARUHAZ_NEV LIKE " + text);

                while (rs.next()) {
                    Aruhaz a = new Aruhaz(
                            rs.getString(1),
                            rs.getString(2)
                    );
                    result.add(a);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            List<Aruhaz> bookList = result;
            MainPageTable.setItems(FXCollections.observableList(bookList));
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        nevCol.setCellValueFactory(new PropertyValueFactory<>("aruhaz_nev"));
        cimHelyCol.setCellValueFactory(new PropertyValueFactory<>("cim_hely"));

        List<Aruhaz> bookList = AruhazController.getInstance().getAll();
        MainPageTable.setItems(FXCollections.observableList(bookList));
    }
}
