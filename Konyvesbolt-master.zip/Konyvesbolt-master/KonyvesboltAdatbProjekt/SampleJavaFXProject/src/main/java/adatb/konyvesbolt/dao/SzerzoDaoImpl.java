package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Szerzo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;

public class SzerzoDaoImpl implements SzerzoDAO {
    @Override
    public boolean add(Szerzo sz) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement st = conn.prepareStatement(INSERT_SZERZO)) {
            st.setInt(1, sz.getSzerzo_id());
            st.setString(2, sz.getSzerzo_nev());
            int res = st.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public List<Szerzo> getAll() {
        List<Szerzo> result = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery(SELECT_SZERZO);

            while (rs.next()) {
                Szerzo sz = new Szerzo(
                        rs.getInt(1),
                        rs.getString(2)
                );
                result.add(sz);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean delete(Szerzo sz) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement pt = conn.prepareStatement("DELETE " +
                "FROM SZERZO WHERE SZERZO_NEV LIKE ?")) {

            pt.setString(1, sz.getSzerzo_nev());

            int res = pt.executeUpdate();
            if (res == 1) {
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean update(Szerzo sz, Szerzo old) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement pt = conn.prepareStatement("UPDATE" +
                " SZERZO SET SZERZO_ID = ?, SZERZO_NEV = ? WHERE SZERZO_NEV = ?")) {

            pt.setInt(1, sz.getSzerzo_id());
            pt.setString(2, sz.getSzerzo_nev());
            pt.setString(3, old.getSzerzo_nev());

            int res = pt.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
