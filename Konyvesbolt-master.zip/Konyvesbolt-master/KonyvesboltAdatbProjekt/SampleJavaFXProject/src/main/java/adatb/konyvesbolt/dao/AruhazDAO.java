package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Aruhaz;
import javafx.scene.control.TableView;

import java.util.List;

public interface AruhazDAO {

    public boolean add(Aruhaz a);
    public List<Aruhaz> getAll();
    public boolean delete(Aruhaz a);
    public boolean update(Aruhaz a, Aruhaz old);
}
