package adatb.konyvesbolt.view.controller;

import adatb.konyvesbolt.controller.SzerzoController;
import adatb.konyvesbolt.model.Szerzo;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class SzerzoUpdateController implements Initializable {
    @FXML
    private TextField idField;
    @FXML
    private TextField nameField;

    @FXML
    private Button okButton;

    public SzerzoUpdateController() {
    }

    @FXML
    public void update(ActionEvent event) {

        Szerzo szerzoOld = SzerzoAdminController.oldSzerzo;

        Szerzo szerzoNew = new Szerzo();
        szerzoNew.setSzerzo_id(Integer.parseInt(idField.getText()));
        szerzoNew.setSzerzo_nev(nameField.getText());

        if(SzerzoController.getInstance().update(szerzoNew, szerzoOld)) {
            AlertsForUser.successAlert("Sikerült a szerző frissítése!");
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        } else {
            AlertsForUser.errorAlert("Hiba történt a szerző frissítése során!");
            return;
        }
    }

    @FXML
    public void cancel(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
