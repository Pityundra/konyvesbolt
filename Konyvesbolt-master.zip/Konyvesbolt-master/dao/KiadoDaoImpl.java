package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Kiado;
import javafx.scene.control.TableView;

import java.util.List;

public class KiadoDaoImpl implements KiadoDAO {
    @Override
    public boolean add(Kiado kiado) {
        return false;
    }

    @Override
    public List<Kiado> getAll() {
        return null;
    }

    @Override
    public boolean delete(TableView table) {
        return false;
    }

    @Override
    public boolean update(TableView table) {
        return false;
    }
}
