package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.model.Konyvesbolt;
import javafx.scene.control.TableView;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static adatb.konyvesbolt.dao.DatabaseStrings.*;
import static adatb.konyvesbolt.dao.DatabaseStrings.INSERT_KONYV;

public class KonyvesboltDaoImpl implements KonyvesboltDAO {
    @Override
    public boolean add(Konyvesbolt kb) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement st = conn.prepareStatement(INSERT_KONYVESBOLT)) {
            st.setString(1, kb.getBolt_nev());
            int res = st.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public List<Konyvesbolt> getAll() {
        List<Konyvesbolt> result = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery(SELECT_KONYVESBOLT);

            while (rs.next()) {
                Konyvesbolt kb = new Konyvesbolt(
                        rs.getString(1)
                );
                result.add(kb);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }


    @Override
    public boolean delete(Konyvesbolt kb) {
        try (Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement pt = conn.prepareStatement("DELETE " +
                "FROM KONYVESBOLT WHERE CIM LIKE BOLT_NEV")) {

            pt.setString(1, kb.getBolt_nev());

            int res = pt.executeUpdate();
            if (res == 1) {
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean update(Konyvesbolt kb, Konyvesbolt old) {
        try(Connection conn = DriverManager.getConnection(DB_STRING, USER, PASSWORD); PreparedStatement pt = conn.prepareStatement("UPDATE" +
                " KONYVESBOLT SET BOLT_NEV = ? WHERE BOLT_NEV = ?")) {

            pt.setString(1, kb.getBolt_nev());
            pt.setString(1, old.getBolt_nev());

            int res = pt.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
