package adatb.konyvesbolt.dao;

public class DatabaseStrings {
    public static final String DB_STRING = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USER = "SYSTEM";
    public static final String PASSWORD = "kicsinyuszi2000";

    public static final String INSERT_ARUHAZ = "INSERT INTO ARUHAZ (ARUHAZ_NEV, CIM_HELY) VALUES " +
            "(?,?)";
    public static final String INSERT_FELHASZNALO = "INSERT INTO FELHASZNALO (ARUHAZ_NEV, CIM_HELY) VALUES " +
            "(?,?)";
    public static final String INSERT_KIADO = "INSERT INTO KIADO (KIADO_NEV) VALUES " +
            "(?)";
    public static final String INSERT_KONYV = "INSERT INTO KONYV (KONYV_ID, CIM, MUFAJ, KIADASI_EV, AR, DARAB) VALUES " +
            "(?,?,?,?,?,?)";
    public static final String INSERT_KONYVESBOLT = "INSERT INTO KONYVESBOLT (BOLT_NEV) VALUES " +
            "(?)";
    public static final String INSERT_SZERZO = "INSERT INTO SZERZO (SZERZO_ID, SZERZO_NEV) VALUES " +
            "(?,?)";

    public static final String SELECT_ARUHAZ = "SELECT * FROM ARUHAZ";
    public static final String SELECT_FELHASZNALO = "SELECT * FROM FELHASZNALO";
    public static final String SELECT_KIADO = "SELECT * FROM KIADO";
    public static final String SELECT_KONYV = "SELECT * FROM KONYV";
    public static final String SELECT_KONYVESBOLT = "SELECT * FROM KONYVESBOLT";
    public static final String SELECT_SZERZO = "SELECT * FROM SZERZO";
}
