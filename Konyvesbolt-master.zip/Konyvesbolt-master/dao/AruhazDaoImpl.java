package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Aruhaz;
import adatb.konyvesbolt.utils.AlertsForUser;
import javafx.scene.control.TableView;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AruhazDaoImpl implements AruhazDAO {

    public AruhazDaoImpl() {
    }

    @Override
    public boolean add(Aruhaz a) {
        try(Connection conn = DriverManager.getConnection(DatabaseStrings.DB_STRING, DatabaseStrings.USER, DatabaseStrings.PASSWORD);
            PreparedStatement pst = conn.prepareStatement(DatabaseStrings.INSERT_ARUHAZ)) {
            pst.setString(1, a.getAruhaz_nev());
            pst.setString(2, a.getCim_hely());

            int res = pst.executeUpdate();
            if(res == 1) return true;

        } catch (SQLException e) {
            AlertsForUser.errorAlert("Hiba történt az Áruház hozzáadásánál!");
        }
        return false;
    }

    @Override
    public List<Aruhaz> getAll() {
        List<Aruhaz> result = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DatabaseStrings.DB_STRING); Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery(DatabaseStrings.SELECT_ARUHAZ);

            while (rs.next()) {
                Aruhaz a = new Aruhaz(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3)
                );
                result.add(a);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public Aruhaz search() {
        return null;
    }

    @Override
    public boolean delete(TableView table) {
        Aruhaz selectedItem = (Aruhaz) table.getSelectionModel().getSelectedItem();
        if(table.getItems().remove(selectedItem)) {
            AlertsForUser.successAlert("Az áruház törlése sikeres!");
            return true;
        } else {
            AlertsForUser.errorAlert("Hiba történt az adott áruház törlésénél!");
            return false;
        }
    }

    @Override
    public boolean update(TableView table) {
        Aruhaz selectedItem = (Aruhaz) table.getSelectionModel().getSelectedItem();
        return false;
    }
}
