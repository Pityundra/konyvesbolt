package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Felhasznalo;
import javafx.scene.control.TableView;

import java.util.List;

public class FelhasznaloDaoImpl implements FelhasznaloDAO {
    @Override
    public boolean add(Felhasznalo f) {
        return false;
    }

    @Override
    public List<Felhasznalo> getAll() {
        return null;
    }

    @Override
    public boolean delete(TableView table) {
        return false;
    }

    @Override
    public boolean update(TableView table) {
        return false;
    }
}
