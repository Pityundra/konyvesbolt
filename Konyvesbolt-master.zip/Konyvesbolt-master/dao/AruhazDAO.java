package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Aruhaz;
import javafx.scene.control.TableView;

import java.util.List;

public interface AruhazDAO {

    public boolean add(Aruhaz a);
    public List<Aruhaz> getAll();
    public Aruhaz search();
    public boolean delete(TableView table);
    public boolean update(TableView table);
}
