package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Felhasznalo;
import javafx.scene.control.TableView;

import java.util.List;

public interface FelhasznaloDAO {

    public boolean add(Felhasznalo f);
    public List<Felhasznalo> getAll();
    public boolean delete(TableView table);
    public boolean update(TableView table);
}
