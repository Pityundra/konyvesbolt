package adatb.konyvesbolt.dao;

import adatb.konyvesbolt.model.Szerzo;
import javafx.scene.control.TableView;

import java.util.List;

public class SzerzoDaoImpl implements SzerzoDAO {
    @Override
    public boolean add(Szerzo sz) {
        return false;
    }

    @Override
    public List<Szerzo> getAll() {
        return null;
    }

    @Override
    public boolean delete(TableView table) {
        return false;
    }

    @Override
    public boolean update(TableView table) {
        return false;
    }
}
