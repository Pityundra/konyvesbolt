package adatb.konyvesbolt.controller;

import adatb.konyvesbolt.dao.FelhasznaloDAO;
import adatb.konyvesbolt.dao.FelhasznaloDaoImpl;
import adatb.konyvesbolt.model.Felhasznalo;
import adatb.konyvesbolt.model.Konyv;
import javafx.scene.control.TableView;

import java.util.List;

public class FelhasznaloController {
    private FelhasznaloDAO dao = new FelhasznaloDaoImpl();

    private static FelhasznaloController instance;

    public static FelhasznaloController getInstance() {
        if(instance == null) {
            instance = new FelhasznaloController();
        }
        return instance;
    }

    private FelhasznaloController() {
    }

    public boolean add(Felhasznalo f) {
        return dao.add(f);
    }

    public List<Felhasznalo> getAll() {
        return dao.getAll();
    }

    public boolean delete(TableView table) {
        return dao.delete(table);
    }

    public boolean update(TableView table) {
        return dao.update(table);
    }
}
