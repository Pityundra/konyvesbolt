package adatb.konyvesbolt.controller;

import adatb.konyvesbolt.dao.KiadoDAO;
import adatb.konyvesbolt.dao.KiadoDaoImpl;
import adatb.konyvesbolt.model.Kiado;
import adatb.konyvesbolt.model.Konyv;
import javafx.scene.control.TableView;

import java.util.List;

public class KiadoController {
    private KiadoDAO dao = new KiadoDaoImpl();

    private static KiadoController instance;

    public static KiadoController getInstance() {
        if(instance == null) {
            instance = new KiadoController();
        }
        return instance;
    }

    private KiadoController() {
    }

    public boolean add(Kiado kiado) {
        return dao.add(kiado);
    }

    public List<Kiado> getAll() {
        return dao.getAll();
    }

    public boolean delete(TableView table) {
        return dao.delete(table);
    }

    public boolean update(TableView table) {
        return dao.update(table);
    }
}
