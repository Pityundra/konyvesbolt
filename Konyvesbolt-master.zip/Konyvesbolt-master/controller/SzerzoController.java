package adatb.konyvesbolt.controller;

import adatb.konyvesbolt.dao.SzerzoDAO;
import adatb.konyvesbolt.dao.SzerzoDaoImpl;
import adatb.konyvesbolt.model.Konyv;
import adatb.konyvesbolt.model.Szerzo;
import javafx.scene.control.TableView;

import java.util.List;

public class SzerzoController {
    private SzerzoDAO dao = new SzerzoDaoImpl();

    private static SzerzoController instance;

    public static SzerzoController getInstance() {
        if(instance == null) {
            instance = new SzerzoController();
        }
        return instance;
    }

    private SzerzoController() {
    }

    public boolean add(Szerzo sz) {
        return dao.add(sz);
    }

    public List<Szerzo> getAll() {
        return dao.getAll();
    }

    public boolean delete(TableView table) {
        return dao.delete(table);
    }

    public boolean update(TableView table) {
        return dao.update(table);
    }
}
