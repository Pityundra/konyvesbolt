package adatb.konyvesbolt.controller;

import adatb.konyvesbolt.dao.AruhazDAO;
import adatb.konyvesbolt.dao.AruhazDaoImpl;
import adatb.konyvesbolt.model.Aruhaz;
import adatb.konyvesbolt.model.Konyv;
import javafx.scene.control.TableView;

import java.util.List;

public class AruhazController {
    private AruhazDAO dao = new AruhazDaoImpl();

    private static AruhazController instance;

    public static AruhazController getInstance() {
        if(instance == null) {
            instance = new AruhazController();
        }
        return instance;
    }

    private AruhazController() {
    }

    public boolean add(Aruhaz a) {
        return dao.add(a);
    }

    public List<Aruhaz> getAll() {
        return dao.getAll();
    }

    public boolean delete(TableView table) {
        return dao.delete(table);
    }

    public boolean update(TableView table) {
        return dao.update(table);
    }
}
